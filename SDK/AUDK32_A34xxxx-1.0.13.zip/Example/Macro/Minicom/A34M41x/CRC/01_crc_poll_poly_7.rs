# A. Description
#    A list of commands here configures CRC module and generates a crc-7 result computed from specific data.
#
# B. Preparation
#    N/A
#
# C. Prerequisite Example (abov_example_config.h)
#    1. CRC 
#
# D. Note
#    Should use Online CRC calculation to compare the result.
#    Link : http://www.ghsi.de/pages/subpages/Online%20CRC%20Calculation/
#
# Please, read the User Manual of the specific chip for more details.
#
# CRC0
# 1. Channel                   : 0 (CRC0)
#
# 2. Config                    : [ 0 p c s m ]
#    Operation                 : p (Polling)
#    Mode                      : c (CRC)
#    CRC Poly                  : s (CRC-7)
#    First-In Bit              : m (MSB)
#
# 3. Data                      : [ 0 7 0x30 0x31 0x32 0x33 0x34 0x35 0x36 ]
#    Data Length               : 7
#    Data                      : 0x30 ... (Hexa and space (delimitor))
#
# CRC-7 Poly       : x^7 + x^3 + x^0
# Result of CRC-7  : 0x0d

# CRC0
send ""

send "cm crc"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

send "uninit 0"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

send "init 0"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

send "config 0 p c s m"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

send "data 0 7 0x30 0x31 0x32 0x33 0x34 0x35 0x36"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

send "cmpt 0 7"
expect {
    "<CRC> # "
    break
    timeout 5 goto end
}

end:

